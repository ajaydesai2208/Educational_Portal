<?php
define('DB_SERVER','fdb29.awardspace.net');
define('DB_USER','3664892_adrian');
define('DB_PASS' ,'Adrian25');
define('DB_NAME', '3664892_adrian');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }

?>

